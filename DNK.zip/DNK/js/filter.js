$(document).ready(function () {
  $("#filter").click(function () {
    $("#filterSection").toggleClass("d-none");
  });
});
